<?php

// check for required fields
if (isset($_POST['Username']) && isset($_POST['Email']) && isset($_POST['Password'])) {
    

    //Connect To Database
    $hostname='procity1999.db.10468841.hostedresource.com';
    $username='procity1999';
    $password='Ayudev98!';

    $con = mysql_connect($hostname,$username,$password);

    if (!$con) {

        $response = -1;
        echo $response;

    } else {

     
        mysql_select_db($username);

        $ensure = "SELECT Username from userinfo WHERE Username = '$usr'";
        $rows = mysql_query($ensure,$con);

        if(mysql_num_rows($rows) > 0) {

             
            $response = array('result'=>"user");
            echo json_encode($response); 
            mysql_close($con);       
            exit;
        }


        // ensure not existing email
        $ensure = "SELECT Email from userinfo WHERE Email = '$email'";
        $rows = mysql_query($ensure,$con);

        if(mysql_num_rows($rows) > 0) {

            $response = array('result'=>"email");
            echo json_encode($response);    
            mysql_close($con);    
            exit;
            
        } 

        $qry = "INSERT INTO userinfo (Username, Email, Pass) VALUES ('$usr', $email', '$pass')";
 

        if (mysql_query($qry)) {

            $message = "Welcome to ProCity, we're currently Beta but you're registered! \n \nProcity Chief Staff";      
            mail($email,'Procity - The Donation Network', $message);
            mysql_close($con); 

            $response = array('result'=>"works");
            echo json_encode($response);    
            
        } else {

            echo "unsuccessful query";
        }

    }

} else {

    echo "no email set";

}

?>