<?php
 
// check for required fields
if (isset($_POST['Username']) && isset($_POST['Password'])) {

    //Connect To Database
    $hostname='procity1999.db.10468841.hostedresource.com';
    $username='procity1999';
    $password='Ayudev98!';

    $con = mysql_connect($hostname,$username, $password);

    if (!$con) {

        $response = array('result'=>"error1");
        echo json_encode($response);

    } else {

        $username = $_POST['Username'];
        $password = $_POST['Password'];

        $qry = "SELECT * FROM userinfo WHERE Username='$username' AND Password='$password'"; 

        $search = mysql_query($qry);

        $rows = mysql_num_rows($search);

        if($rows > 0){

            $response = array('result'=>"present");
            echo json_encode($response); 

        } else {

            $response = array('result'=>"notpresent");
            echo json_encode($response); 

        }

        mysql_close($con);


} else {

        $response = array('result'=>"error2");
        echo json_encode($response);

}

?>